import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
from model import YOLOv8

# Use CPU
device = torch.device('cpu')

# Data Loading
train_dataset = datasets.MNIST(
    root='data', train=True, download=True, transform=ToTensor())
train_loader = DataLoader(train_dataset, batch_size=8,
                          shuffle=True, num_workers=0)

# Initialize Model, Loss Function, and Optimizer
model = YOLOv8(nc=10).to(device)  # Set nc to 10 for MNIST (10 classes)
optimizer = optim.Adam(model.parameters(), lr=1e-3)
criterion = nn.CrossEntropyLoss()

# Training Loop
for epoch in range(10):  # Number of epochs
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

    epoch_loss = running_loss / len(train_loader)
    print(f'Epoch {epoch + 1}, Loss: {epoch_loss:.4f}')

# Save the trained model
torch.save(model.state_dict(), 'yolov8_model.pth')
