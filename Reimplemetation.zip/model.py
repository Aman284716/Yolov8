import torch
import torch.nn as nn

class Conv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=1, stride=1, padding=0):
        super(Conv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class C2f(nn.Module):
    def __init__(self, in_channels, out_channels, shortcut=True):
        super(C2f, self).__init__()
        self.conv1 = Conv(in_channels, out_channels // 2, kernel_size=1)
        self.conv2 = Conv(out_channels // 2, out_channels // 2, kernel_size=3, padding=1)
        self.conv3 = Conv(out_channels // 2, out_channels, kernel_size=1)
        self.shortcut = shortcut

    def forward(self, x):
        if self.shortcut:
            return self.conv3(self.conv2(self.conv1(x))) + x
        else:
            return self.conv3(self.conv2(self.conv1(x)))

class SPPF(nn.Module):
    def __init__(self, in_channels, out_channels, pool_sizes=[5]):
        super(SPPF, self).__init__()
        self.pool = nn.ModuleList([nn.MaxPool2d(size, stride=1, padding=size // 2) for size in pool_sizes])
        self.conv = Conv(in_channels * (len(pool_sizes) + 1), out_channels, kernel_size=1)

    def forward(self, x):
        pooled = [x] + [p(x) for p in self.pool]
        return self.conv(torch.cat(pooled, dim=1))

class Concat(nn.Module):
    def __init__(self, dim):
        super(Concat, self).__init__()
        self.dim = dim

    def forward(self, x):
        return torch.cat(x, dim=self.dim)

class Detect(nn.Module):
    def __init__(self, nc, anchors=9):
        super(Detect, self).__init__()
        self.nc = nc
        self.anchors = anchors
        self.detect = nn.ModuleList([Conv(256, anchors * (nc + 5), kernel_size=1) for _ in range(3)])

    def forward(self, x):
        return [d(x) for d in self.detect]

class YOLOv8(nn.Module):
    def __init__(self, nc=10):  # Adjusted for MNIST with 10 classes
        super(YOLOv8, self).__init__()
        # Backbone
        self.backbone = nn.Sequential(
            Conv(1, 64, kernel_size=3, stride=2, padding=1),  # Updated for 1 channel
            Conv(64, 128, kernel_size=3, stride=2, padding=1),
            C2f(128, 128),
            Conv(128, 256, kernel_size=3, stride=2, padding=1),
            C2f(256, 256),
            Conv(256, 512, kernel_size=3, stride=2, padding=1),
            C2f(512, 512),
            Conv(512, 1024, kernel_size=3, stride=2, padding=1),
            C2f(1024, 1024),
            SPPF(1024, 1024, [5])
        )

        # Calculate the size of the feature map after all conv layers
        self.feature_map_size = self._get_feature_map_size(28)  # MNIST images are 28x28
        self.fc = nn.Linear(1024 * self.feature_map_size * self.feature_map_size, nc)

    def _get_feature_map_size(self, input_size):
        size = input_size
        for layer in self.backbone:
            if isinstance(layer, Conv):
                size = (size - layer.conv.kernel_size[0] + 2 * layer.conv.padding[0]) // layer.conv.stride[0] + 1
        return size

    def forward(self, x):
        x = self.backbone(x)
        x = x.view(x.size(0), -1)  # Flatten
        x = self.fc(x)
        return x
