import torch
from PIL import Image
from torchvision.transforms import ToTensor
from model import YOLOv8

# Load the trained model
model = YOLOv8(nc=10).to('cpu')
model.load_state_dict(torch.load('yolov8_model.pth'))
model.eval()

# Preprocess the image
img = Image.open('test_image.jpg').convert('RGB')  # Replace with path to your test image
img = img.resize((224, 224))  # Resize to match input size of model
img_tensor = ToTensor()(img).unsqueeze(0).to('cpu')  # Convert to tensor and add batch dimension

# Make predictions
with torch.no_grad():
    outputs = model(img_tensor)
    _, predicted = torch.max(outputs, 1)
    print(f'Predicted class: {predicted.item()}')
